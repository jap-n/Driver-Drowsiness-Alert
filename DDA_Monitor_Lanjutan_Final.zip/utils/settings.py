import tkinter as tk
from tkinter import simpledialog

class Settings:
    def __init__(self):
        self.sensitivity = "Medium"
        self.threshold_sedang = 10
        self.threshold_berat = 20
        self.threshold_tertidur = 30
        self.camera_index = 0

    def open_settings_window(self):
        root = tk.Tk()
        root.withdraw()

        self.sensitivity = simpledialog.askstring("Sensitivitas", "Pilih sensitivitas (Low, Medium, High):", initialvalue="Medium")
        self.threshold_sedang = simpledialog.askinteger("Threshold Sedang", "Skor minimum kantuk sedang:", initialvalue=10)
        self.threshold_berat = simpledialog.askinteger("Threshold Berat", "Skor minimum kantuk berat:", initialvalue=20)
        self.threshold_tertidur = simpledialog.askinteger("Threshold Tidur", "Skor minimum tertidur:", initialvalue=30)
        self.camera_index = simpledialog.askinteger("Kamera Index", "Pilih Kamera (biasanya 0):", initialvalue=0)

        root.destroy()