import time
import os

LOG_FILE = "logs/events.txt"

def save_event(event_type, duration):
    timestamp = int(time.time())
    with open(LOG_FILE, "a") as f:
        f.write(f"{timestamp},{event_type},{duration:.2f}\n")

def get_recent_logs():
    recent_events = []
    now = int(time.time())
    if not os.path.exists(LOG_FILE):
        return recent_events

    with open(LOG_FILE, "r") as f:
        lines = f.readlines()
        for line in lines:
            parts = line.strip().split(",")
            if len(parts) == 3:
                ts, event, dur = int(parts[0]), parts[1], float(parts[2])
                if now - ts <= 600:
                    recent_events.append((event, dur))
    return recent_events

def calculate_score(events):
    score = 0
    for event, dur in events:
        if event == "kedip":
            score += 1
        elif event == "menguap":
            score += 3
        elif event == "microsleep":
            score += 10
    return score