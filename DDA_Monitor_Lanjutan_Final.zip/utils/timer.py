import time

class FPSTimer:
    def __init__(self):
        self.last = time.time()

    def update(self):
        now = time.time()
        fps = 1 / (now - self.last)
        self.last = now
        return fps
